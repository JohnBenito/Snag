import json

data={"username": "Scott", "mouseclick": "yes","mousemove": "yes", "keypress": "yes", "device": "desktop", "browser":"chrome","eventdate":"2019-02-22","eventtime":"14:00:00"}
bot_score=0
for k,v in data.items():
    if k in ["mousemove", "keypress", "timeinterval"]:
        bot_score = bot_score + 0.33
if (bot_score <0.5):
    print("Its a BOT")
else:
    print("Humans .... ")
